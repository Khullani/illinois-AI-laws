# M365 Lead Capture Setup Guide
## Illinois AI Compliance Readiness — Technê AI

This guide walks you through setting up the complete lead capture pipeline using your existing Microsoft 365 subscription.

---

## Architecture Overview

```
[Visitor lands on Compliance Strategy page]
        ↓
[Takes interactive readiness assessment]
        ↓
[Sees gaps + risk score → urgency created]
        ↓
[Two conversion paths:]
   ├─→ "Get Your Report" → Microsoft Form (captures lead + assessment data)
   │         ↓
   │    Power Automate → sends personalized results email
   │         ↓
   │    Lead appears in your tracking spreadsheet/list
   │
   └─→ "Book a Strategy Session" → Microsoft Bookings
              ↓
         30-min consultation auto-scheduled
```

---

## Step 1: Create the Microsoft Form

### Go to: https://forms.office.com → New Form

**Form Title:** Illinois AI Compliance — Get Your Readiness Report  
**Description:** Based on your assessment results, we'll send you a personalized compliance gap analysis with specific action items for your organization.

### Questions to Create:

| # | Question | Type | Required | Notes |
|---|----------|------|----------|-------|
| 1 | Full Name | Text | Yes | Short answer |
| 2 | Work Email | Text | Yes | Add email validation |
| 3 | Organization | Text | Yes | Short answer |
| 4 | Your Role/Title | Text | Yes | Short answer |
| 5 | Which best describes your organization? | Choice | Yes | Options below |
| 6 | How many employees in Illinois? | Choice | Yes | Options below |
| 7 | Are you currently using AI in any business operations? | Choice | Yes | Yes / No / Not Sure |
| 8 | Which areas involve AI? (select all) | Multi-choice | No | Show if Q7 = Yes. Options below |
| 9 | How would you rate your current AI compliance readiness? | Rating | Yes | 1-5 stars |
| 10 | What's your biggest compliance concern? | Long text | No | Optional open-ended |
| 11 | How urgently do you need guidance? | Choice | Yes | Options below |
| 12 | Would you like to schedule a free 30-min strategy session? | Choice | Yes | Yes / Not yet |

### Choice Options:

**Q5 — Organization Type:**
- Employer (any industry)
- Healthcare / Mental Health Provider
- K-12 School or District
- Higher Education
- Content / Media / Creative Agency
- Technology / AI Developer
- Government / Public Sector
- Financial Services
- Real Estate
- Other

**Q6 — Employee Count:**
- 1-49
- 50-249
- 250-999
- 1,000-4,999
- 5,000+

**Q8 — AI Use Areas (multi-select):**
- Recruiting / Hiring / HR
- Customer Service (chatbots, virtual agents)
- Marketing / Content Creation
- Clinical / Patient Care
- Student Assessment / Education
- Data Analysis / Reporting
- Sales / CRM
- Legal / Compliance
- Other

**Q11 — Urgency:**
- Immediately — we have active compliance gaps
- Within 30 days
- Within 90 days — planning ahead
- Just exploring / researching

### Form Settings:
1. **Settings → Responses**: Turn ON "Get email notification of each response"
2. **Settings → Responses**: Connect to an Excel spreadsheet (auto-creates in OneDrive)
3. **Completion message**: "Thanks! Your personalized compliance gap report is on its way. If you'd like to accelerate — [book a free strategy session with Technê AI](YOUR_BOOKINGS_LINK)."
4. **Theme**: Use your Technê AI brand colors (dark theme if possible)

### Get the Form URLs:
- **Share → Embed**: Copy the iframe embed code
- **Share → Link**: Copy the direct form link
- You'll paste these into the HTML artifact (look for `YOUR_FORM_EMBED_URL` and `YOUR_FORM_LINK`)

---

## Step 2: Create the Microsoft Bookings Service

### Go to: https://outlook.office.com/bookings → Create new booking page

**Business Name:** Technê AI — AI Compliance Strategy  
**Business Type:** Consulting  

### Create the Service:

**Service Name:** Free AI Compliance Strategy Session  
**Description:** A 30-minute consultation to review your organization's Illinois AI compliance readiness, identify critical gaps, and build a prioritized action plan.  
**Duration:** 30 minutes  
**Price:** Free  
**Buffer time:** 15 minutes after  
**Max attendees:** 1  

### Custom Questions (add these to the booking form):
1. "What's your organization's name?" (Required, text)
2. "Which sector?" (Required, dropdown: Employer / Healthcare / Education / Creative-Media / Tech / Government / Financial / Other)
3. "What's your most pressing AI compliance question?" (Optional, text)

### Availability Settings:
- Set your preferred consultation hours
- Suggested: Mon-Fri, 9am-4pm CT with 30-min slots
- Enable Teams meeting auto-generation

### Booking Page Settings:
1. Turn ON "Allow customers to choose a specific staff member"
2. Add your photo and bio
3. Customize the page colors to match Technê AI branding

### Get the Bookings URL:
- **Share → Booking page link**: Copy the URL
- You'll paste this into the HTML artifact (look for `YOUR_BOOKINGS_URL`)

---

## Step 3: Power Automate — Connect Form to Email Response

### Go to: https://make.powerautomate.com → Create → Automated cloud flow

**Trigger:** "When a new response is submitted" (Microsoft Forms)  
**Select form:** Illinois AI Compliance — Get Your Readiness Report

### Flow Steps:

```
1. TRIGGER: When new response submitted (Microsoft Forms)
        ↓
2. ACTION: Get response details (Microsoft Forms)
        ↓
3. ACTION: Send an email (V2) — TO THE LEAD
   - To: [Q2 Work Email]
   - Subject: Your Illinois AI Compliance Readiness Report — Technê AI
   - Body: (see email template below)
        ↓
4. ACTION: Send an email (V2) — INTERNAL NOTIFICATION
   - To: your-email@techne.ai
   - Subject: 🔔 New Lead: [Q1 Name] at [Q3 Organization] — [Q11 Urgency]
   - Body: Full form responses + urgency flag
        ↓
5. (OPTIONAL) ACTION: Add a row to Excel
   - File: Your leads tracking spreadsheet
   - Table: Leads
   - Map all form fields to columns
```

### Email Template for the Lead (Step 3 body):

```html
Hi [Q1 Name],

Thanks for taking the Illinois AI Compliance Readiness Assessment.

Based on your responses, here's a quick summary of your situation:

ORGANIZATION: [Q3]
SECTOR: [Q5]
AI IN USE: [Q7]
SELF-RATED READINESS: [Q9] / 5
URGENCY: [Q11]

━━━━━━━━━━━━━━━━━━━━━━━━━━━

KEY STATUTES AFFECTING YOUR ORGANIZATION:

[If Q5 = Employer/any] → PA 103-0804 (AI Employment Discrimination Act) — effective NOW
[If Q5 = Healthcare] → PA 104-0539 (WOPR Act) — effective since Aug 2025
[If Q5 = Education] → PA 104-0399 (Public Education AI Guidelines) — effective NOW
[If Q5 = Creative/Media] → PA 103-0882/0880 (Voice & Likeness Protection) — effective since Aug 2024

The Illinois AI regulatory landscape now includes 7 enacted statutes and 29 pending bills.
IDHR is currently finalizing enforcement rules for the AI Employment Discrimination Act.

━━━━━━━━━━━━━━━━━━━━━━━━━━━

NEXT STEPS:

→ View the full compliance action plan: https://strategy.techne.ai/illinois-AI-laws/compliance.html
→ Book a free 30-min strategy session: [YOUR_BOOKINGS_URL]
→ Explore the full bill tracker: https://strategy.techne.ai/illinois-AI-laws/

Technê AI helps organizations navigate Illinois AI compliance — from policy drafting
and bias audits to training programs and vendor due diligence.

Best,
[Your Name]
Technê AI
```

### Conditional Logic (Advanced):
In Power Automate, you can use **Condition** actions to customize the email content based on sector (Q5) and urgency (Q11). For "Immediately" urgency responses, consider adding a priority flag to the internal notification.

---

## Step 4: Update the HTML Artifact

The artifact file (`illinois-ai-compliance-strategy.html`) has placeholder values you need to replace:

| Find This | Replace With |
|-----------|-------------|
| `YOUR_FORM_EMBED_URL` | Your Microsoft Form embed URL (from Forms → Share → Embed) |
| `YOUR_FORM_LINK` | Your Microsoft Form direct link (from Forms → Share → Link) |
| `YOUR_BOOKINGS_URL` | Your Microsoft Bookings page URL |

The form appears in two places:
1. **After the assessment results** — embedded iframe for immediate lead capture
2. **CTA buttons throughout** — link to Bookings for scheduling

---

## Step 5: Lead Tracking Spreadsheet

When you connect your Form to an Excel spreadsheet (Form → Settings → Responses → Open in Excel), it auto-creates columns for each question. Add these manual columns for your pipeline tracking:

| Column | Purpose |
|--------|---------|
| Status | New / Contacted / Meeting Scheduled / Proposal Sent / Closed-Won / Closed-Lost |
| Follow-up Date | Next action date |
| Notes | Conversation notes |
| Revenue | Estimated engagement value |
| Source | Auto-fill "IL AI Compliance Page" |

---

## Quick Reference: All URLs You Need

| Asset | Where to Create | Where It Goes |
|-------|----------------|---------------|
| Form embed URL | forms.office.com → Share → Embed | `YOUR_FORM_EMBED_URL` in artifact |
| Form direct link | forms.office.com → Share → Link | `YOUR_FORM_LINK` in artifact |
| Bookings URL | outlook.office.com/bookings → Share | `YOUR_BOOKINGS_URL` in artifact + form completion message + email template |

---

## Testing Checklist

- [ ] Submit a test form response — verify you receive the email notification
- [ ] Check that responses appear in your Excel spreadsheet
- [ ] Verify the Power Automate flow sends both the lead email and internal notification
- [ ] Test the Bookings link — confirm availability shows correctly
- [ ] Load the HTML artifact and verify the Form embed renders
- [ ] Test on mobile — ensure Form and Bookings are responsive
- [ ] Submit from the artifact's assessment → verify the full flow end-to-end
